<?php
include_once 'connection/conn.php';

    try {
        $conn->beginTransaction();

        $paciente = $_POST['name_pacient'] ;
        $contact = $_POST['phone'];
        $email = $_POST['email'];
        $type = $_POST['especialidade'];
        $medico = $_POST['medico'];
        $date_consult = $_POST['date_consult'];
        $horario_id  = $_POST['hour_disponible'];
        $observacoes = $_POST['observation'] ?? '';

        $check = $conn->prepare(
            "SELECT COUNT(*) FROM tb_consulta
             WHERE horario_id = ? AND status = 'Agendada'"
        );
        $check->execute([$horario_id]);

        if ($check->fetchColumn() > 0) {
            throw new Exception("Horário indisponível para este médico.");
        }
        if (!$horario_id) {
        throw new Exception("Horário não foi enviado.");
        }

            $check_paciente = $conn->prepare(
                "SELECT id FROM tb_paciente WHERE nome_completo = ? AND telefone = ?"
            );      
            $check_paciente->execute([$paciente, $contact]);
            $paciente_id = $check_paciente->fetchColumn(); 

            $check_email = $conn->prepare("SELECT id from tb_us where email = ?");
            $check_email->execute([$email]);
            $email_user = $check_email->fetchColumn();  

            if (!$paciente_id && $email_user) {
                throw new Exception("Paciente não encontrado.");
            }

            $stmt = $conn->prepare(
            "INSERT INTO tb_consulta
             (horario_id, paciente_id, observacoes)
             VALUES (?, ?, ?)"
        );
        $stmt->execute([
            $horario_id,
            $paciente_id,
            $observacoes
        ]);
      

        $conn->commit();
        echo json_encode(["message" => "Consulta agendada com sucesso!", "status" => "ok"]);

    } catch (Exception $e) {
        $conn->rollBack();
        echo json_encode([
            "message" => "Erro ao agendar consulta: " . $e->getMessage(),
            "status" => "error"
        ]);
    }
    
?>
