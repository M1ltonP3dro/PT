<?php

include_once 'connection/conn.php';

try{
    $sql_pacientes = "SELECT COUNT(*) FROM tb_paciente";
    $sql_consulta_today = "SELECT COUNT(*) FROM tb_consulta";
    $sql_consultas_pendentes = "SELECT COUNT(*) FROM tb_consulta where status = 'pendente' ";
    $sql_medicos_ativos = "SELECT COUNT(*) FROM tb_medico where status = 'ativo'";

    $pacientes = $conn->query($sql_pacientes);
    $consultas = $conn->query($sql_consulta_today);
    $pendentes = $conn->query($sql_consultas_pendentes);
    $ativos = $conn->query($sql_medicos_ativos);

    echo json_encode([
        "total_pacientes" => $pacientes->fetchColumn(),
        "total_consultas_today" => $consultas->fetchColumn(),
        "total_consultas_pendentes" => $pendentes->fetchColumn(),
        "total_medicos_ativos" => $ativos->fetchColumn(),
        "status" => "ok"
    ]);
}
catch(Exception $e){
    echo json_encode([
        "status" => "error",
        "message" => "Erro ao carregar os dados do banco de dados: " . $e->getMessage()
    ]);
    exit();
}