<?php
include_once 'connection/conn.php';

 try {
       
  if(isset($_GET['medico_id'])){
           $medicoselect = $_GET['medico_id'];

              $sqlhour = $conn->prepare("SELECT id, hora_inicio, hora_fim FROM tb_horario WHERE medico_id = ?");
             $sqlhour->execute([$medicoselect]);
     
            $resp = $sqlhour->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode([
                 "horarios" => $resp, 
                  "status" => "ok"
            ]);
            exit();
        }
        else{
            echo json_encode([
                "status" => "error",
                "message" => "medico não foi selecionado"]);
        }
}
catch(Exception $e){
    echo json_encode("Erro ao carregar horários: " . $e->getMessage());
}