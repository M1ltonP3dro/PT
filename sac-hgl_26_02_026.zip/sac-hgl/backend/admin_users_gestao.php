<?php

include_once 'connection/conn.php';
header('Content-Type: application/json');

try{

   $sql = $conn->prepare("SELECT p.nome_completo, u.email, u.status, 'paciente' AS nome FROM tb_paciente p INNER JOIN tb_us u ON u.id = p.us_id 
   UNION 
   SELECT f.nome_completo, u.email, u.status, f.cargo_id AS nome FROM tb_funcionario f INNER JOIN tb_us u ON u.id = f.us_id
   ");
    $sql->execute();
    $users = $sql->fetchAll(PDO::FETCH_ASSOC);


    $sql_consultas = $conn->prepare("SELECT h.data, h.hora_inicio, p.nome_completo as paciente, f.nome_completo AS medico, c.status FROM tb_consulta c INNER JOIN tb_horario h ON h.id = c.horario_id INNER JOIN tb_paciente p ON p.id = c.paciente_id INNER JOIN tb_medico m on m.id = h.medico_id INNER JOIN tb_funcionario f ON f.id = m.funcionario_id");
    $sql_consultas->execute();
    $consultas = $sql_consultas->fetchAll(PDO::FETCH_ASSOC);

    $sql_medicos = $conn->prepare("SELECT m.status, f.data_admissao, f.nome_completo AS name, f.phone AS phone, e.nome AS especiality FROM tb_medico m INNER JOIN tb_funcionario f ON f.id = m.funcionario_id INNER JOIN tb_medico_especialidade me ON me.medico_id = m.id INNER JOIN tb_especialidade e ON e.id = me.especialidade_id;");
    $sql_medicos->execute();
    $medicos = $sql_medicos->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        "users" => $users,
        "consultas" => $consultas,
        "medicos" => $medicos,
        "status" => "ok"
    ]);

} catch(Exception $e){
    echo json_encode([
        "status" => "error",
        "message" => "Erro ao carregar os dados do banco de dados: " . $e->getMessage()
    ]);
    exit();
}