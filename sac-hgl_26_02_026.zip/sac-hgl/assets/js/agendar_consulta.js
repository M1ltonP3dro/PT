const form_agendamento = document.querySelector("#agendamentoForm");

// Seleciona os elementos do formulário

const especialidade = document.querySelector("#especialidade");
const medico = document.querySelector("#medico");
const data = document.querySelector("#data");
const hora = document.querySelector("#horario");

// Função para carregar as especialidades do banco de dados
async function load_especialidade(){
// Faz uma requisição para o backend para obter as especialidades
    const response_sr = await fetch("backend/return_datas_db.php")
    const data = await response_sr.json()
    // Extrai as especialidades da resposta do backend
    const especialidades = data.especialidades 
    console.log(especialidades)

    especialidade.innerHTML = '<option value="">Selecione</option>'
// Preenche o select de especialidades com os dados do banco de dados
    especialidades.forEach(esp => {
        const option = document.createElement("option")
        option.value = esp.id
        option.textContent = esp.nome
        especialidade.appendChild(option)
    })
}

load_especialidade()
// Evento para carregar os médicos com base na especialidade selecionada
especialidade.addEventListener("change", async () => {
    
    const id_esp = especialidade.value 
    const response_sr = await fetch(`backend/return_datas_db.php?especialidade_id=${id_esp}`)
    const data_med = await response_sr.json()
    const medicos = data_med.medicos
    console.log(medicos)
    medico.innerHTML = '<option value="">Selecione o médico</option>'
    // Preenche o select de médicos com os dados do banco de dados
    medicos.forEach(med => {
        const option = document.createElement("option") 
        option.value = med.medico_id
        option.textContent = med.nome_completo
        medico.appendChild(option)
    })
})

medico.addEventListener("change", async () => {
    
    const id_med = medico.value 
    const response_server = await fetch(`backend/hora_data.php?medico_id=${id_med}`)
    const hour_med = await response_server.json()
    const horario = hour_med.horarios
    console.log(horario)
    hora.innerHTML = '<option value="">Selecione o horário</option>'
    
    horario.forEach(hour => {
        const option = document.createElement("option") 
        option.value = hour.id
        option.textContent = hour.hora_inicio
        hora.appendChild(option)
    })
})

form_agendamento.addEventListener("submit", event => send(event));

async function send(event){
    event.preventDefault()
    try{
        const form_agendamento = event.target
        const form = new FormData(form_agendamento)

        const response = await fetch("backend/agendamento.php",{
            method: "POST",
            body: form  
        }) 
        const response_server = await response.json()
        console.log(response_server)
        
     if(response_server.status === "ok"){
           alert(response_server.message)
             window.location.href = "painel.php" 
        }
        else{
            console.log("Erro no agendamento")
        }
        
    }catch(error){
        console.log("Erro ao enviar o formulário:", error)
    }   
     
}