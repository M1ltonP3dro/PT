

const total_pacientes = document.getElementById('totalPacientes');
const total_consultas_today = document.getElementById('totalConsultas_today');
const total_consultas_pendentes = document.getElementById('totalConsultasPendentes');
const total_medicos_ativos = document.getElementById('totalMedicos_ativos');

async function carregar_estatisticas(){
    try {
        const response = await fetch('backend/admin_total.php');
        const data = await response.json();

        if(data.status === "ok"){

        total_pacientes.textContent = data.total_pacientes;
        total_consultas_today.textContent = data.total_consultas_today;
        total_consultas_pendentes.textContent = data.total_consultas_pendentes;
        total_medicos_ativos.textContent = data.total_medicos_ativos;
        }
        else {
            console.log("Algo causou o erro:", data.message);
        }
    } catch (error) {
        console.error('Erro ao carregar estatísticas:', error);
    }
}
carregar_estatisticas()

const name_user = document.querySelector("#name_user")
const email_user = document.querySelector("#email_user")
const type_user = document.querySelector("#type_user")
const status_user = document.querySelector("#status_user")
const table_users = document.querySelector("#table_users")

async function carregar_dados_usuario(){
    try {
        const response = await fetch('backend/admin_users_gestao.php');
        const data = await response.json(); 
        const users = data.users
        console.log(users)

        users.forEach(u =>{

            tr = document.createElement("tr")

            const tdNome = document.createElement("td")
            tdNome.textContent = u.nome_completo

            const tdEmail = document.createElement("td")
            tdEmail.textContent = u.email

            const tdType = document.createElement("td")
            tdType.textContent = u.nome === "1" ? "medico" : u.nome === "2" ? "secretario" : "Paciente"

            const tdStatus = document.createElement("td")
            tdStatus.textContent = u.status

            tr.appendChild(tdNome)
            tr.appendChild(tdEmail)
            tr.appendChild(tdType)
            tr.appendChild(tdStatus)

            table_users.appendChild(tr)
        })
    }
    catch(error){
        console.error('Erro ao carregar dados do usuário:', error);
    }   
}
carregar_dados_usuario()

const table_consultas = document.querySelector("#table_consultas")

async function carregar_consultas() {
    try{
    const response_server = await fetch("backend/admin_users_gestao.php")
    const data_consultas = await response_server.json()
    const consultas = data_consultas.consultas
    console.log(consultas)

    consultas.forEach( c => {
        const tr = document.createElement("tr")

        const td_date = document.createElement("td")
        td_date.textContent = c.data

        const td_hour = document.createElement("td")
        td_hour.textContent = c.hora_inicio

        const td_paciente = document.createElement("td")
        td_paciente.textContent = c.paciente

        const td_medico = document.createElement("td")
        td_medico.textContent = c.medico

        const td_status = document.createElement("td")
        td_status.textContent = c.status 

        tr.appendChild(td_date)
        tr.appendChild(td_hour)
        tr.appendChild(td_paciente)
        tr.appendChild(td_medico)
        tr.appendChild(td_status)

        table_consultas.appendChild(tr)

    })
     
    } catch(error){
        console.error('Erro ao carregar consultas:', error);
    }
}
carregar_consultas()

const table_medicos = document.querySelector("#table_medicos")

async function carregar_medicos() {
    try{
    const response_server = await fetch("backend/admin_users_gestao.php")
    const data = await response_server.json()
    const medicos = data.medicos
    console.log(medicos)

    medicos.forEach( m => {
        const tr = document.createElement("tr")

        const td_name = document.createElement("td")
        td_name.textContent = m.name

        const td_especiality = document.createElement("td")
        td_especiality.textContent = m.especiality

        const td_contact = document.createElement("td")
        td_contact.textContent = m.phone

        const td_data_admiss = document.createElement("td")
        td_data_admiss.textContent = m.data_admissao

        const td_status = document.createElement("td")
        td_status.textContent = m.status 

        tr.appendChild(td_name)
        tr.appendChild(td_especiality)
        tr.appendChild(td_contact)
        tr.appendChild(td_data_admiss)
        tr.appendChild(td_status)

        table_medicos.appendChild(tr)

    })
     
    } catch(error){
        console.error('Erro ao carregar medicos:', error);
    }
}
carregar_medicos()