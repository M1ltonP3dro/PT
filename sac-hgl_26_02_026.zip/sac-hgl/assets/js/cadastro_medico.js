
document.querySelector("#time_consult").addEventListener("click", function () {
  document.querySelector(".modal").style.display = "flex";
})

document.querySelector(".close-modal").addEventListener("click", function () {
  document.querySelector(".modal").style.display = "none";
})
document.querySelector(".btn-cancel").addEventListener("click", function () {
  document.querySelector(".modal").style.display = "none";
})






const mostrar_form = document.querySelector("#step2")
const desaparecer = document.querySelector("#step1")

function handleNext(){
    desaparecer.style.display="none"
    mostrar_form.style.display="flex"
}
function goBackToStep1(){
    mostrar_form.style.display="none"
    desaparecer.style.display="block"
}

function goToLogin(){
    window.location.href="login.html"
}


const formulario = document.getElementById("form_sac_hgl");

formulario.addEventListener("submit", event => send(event));

async function send(event){
    event.preventDefault()
    try{
        const formulario = event.target
        const form = new FormData(formulario)

        const response = await fetch("backend/cadastro_medico.php",{  
            method: "POST",
            body: form
        }) 
        const response_server = await response.json()
        console.log(response_server)
        
        if(response_server.success === true){
            alert(response_server.message);
            window.location.href="index.html"
        }else{
            alert(response_server.message);
        }
                 
    }catch(error){
        console.error("Erro ao enviar o formulário:", error)
    }    
}