-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 26/02/2026 às 23:42
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `sac_hgl`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_cargo`
--

CREATE TABLE `tb_cargo` (
  `id` int(11) NOT NULL,
  `nome` varchar(80) NOT NULL,
  `descricao` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `tb_cargo`
--

INSERT INTO `tb_cargo` (`id`, `nome`, `descricao`) VALUES
(1, 'medico', 'curar'),
(2, 'secretario', 'papelada'),
(3, 'paciente', 'doente');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_consulta`
--

CREATE TABLE `tb_consulta` (
  `id` int(11) NOT NULL,
  `horario_id` int(11) NOT NULL,
  `paciente_id` int(11) NOT NULL,
  `status` enum('Pendente','Confirmada','Concluída','Cancelada') DEFAULT 'Pendente',
  `observacoes` longtext DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `tb_consulta`
--

INSERT INTO `tb_consulta` (`id`, `horario_id`, `paciente_id`, `status`, `observacoes`, `created_at`) VALUES
(1, 1, 10, '', 'Gripe', '2026-02-26 09:18:43'),
(2, 1, 15, '', 'Tosse', '2026-02-26 09:20:55'),
(3, 1, 13, '', 'Entorse ', '2026-02-26 09:41:49'),
(4, 4, 1, '', 'Febre', '2026-02-26 09:59:49'),
(5, 5, 4, 'Pendente', 'Dificuldades respiratórias', '2026-02-26 13:08:36');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_especialidade`
--

CREATE TABLE `tb_especialidade` (
  `id` int(11) NOT NULL,
  `nome` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `tb_especialidade`
--

INSERT INTO `tb_especialidade` (`id`, `nome`) VALUES
(4, 'cardiologia'),
(9, 'clinica_geral'),
(7, 'dermatologia'),
(5, 'oftamologia'),
(8, 'optometria'),
(6, 'pediatria');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_funcionario`
--

CREATE TABLE `tb_funcionario` (
  `id` int(11) NOT NULL,
  `us_id` int(11) NOT NULL,
  `data_admissao` timestamp NOT NULL DEFAULT current_timestamp(),
  `nome_completo` varchar(120) NOT NULL,
  `cargo_id` int(11) NOT NULL,
  `phone` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `tb_funcionario`
--

INSERT INTO `tb_funcionario` (`id`, `us_id`, `data_admissao`, `nome_completo`, `cargo_id`, `phone`) VALUES
(15, 52, '2026-02-07 22:18:06', 'Mario Vasco', 1, '951334715'),
(16, 53, '2026-02-07 22:20:35', 'Conceição Pedro', 1, '921921221'),
(18, 55, '2026-02-08 17:15:06', 'Emanuel Lopes', 1, '951334715'),
(19, 56, '2026-02-08 17:17:23', 'Kelcio Palma', 1, '921921221'),
(20, 57, '2026-02-09 09:14:22', 'as', 1, '921921221'),
(21, 58, '2026-02-26 09:58:25', 'Haniel Coimbra', 1, '927574720'),
(22, 59, '2026-02-26 12:22:25', 'Priscila Agostinho', 1, '935354708'),
(23, 60, '2026-02-26 17:37:50', 'Azancot Menezes ', 2, '929384912');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_horario`
--

CREATE TABLE `tb_horario` (
  `id` int(11) NOT NULL,
  `medico_id` int(11) NOT NULL,
  `data` date NOT NULL,
  `hora_inicio` time NOT NULL,
  `hora_fim` time NOT NULL,
  `disponivel` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `tb_horario`
--

INSERT INTO `tb_horario` (`id`, `medico_id`, `data`, `hora_inicio`, `hora_fim`, `disponivel`) VALUES
(1, 12, '2024-06-01', '00:00:09', '12:00:00', 1),
(2, 13, '2024-06-01', '00:00:09', '12:00:00', 1),
(3, 14, '2024-06-01', '09:00:00', '12:00:00', 1),
(4, 15, '2024-06-01', '09:35:00', '12:00:00', 1),
(5, 16, '2024-06-01', '10:35:00', '12:00:00', 1),
(6, 17, '2024-06-01', '09:00:00', '12:00:00', 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_medico`
--

CREATE TABLE `tb_medico` (
  `id` int(11) NOT NULL,
  `funcionario_id` int(11) NOT NULL,
  `status` enum('ativo','afastado') DEFAULT 'ativo'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `tb_medico`
--

INSERT INTO `tb_medico` (`id`, `funcionario_id`, `status`) VALUES
(9, 15, 'ativo'),
(10, 16, 'ativo'),
(12, 18, 'ativo'),
(13, 19, 'ativo'),
(14, 20, 'ativo'),
(15, 21, 'ativo'),
(16, 22, 'ativo'),
(17, 23, 'ativo');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_medico_especialidade`
--

CREATE TABLE `tb_medico_especialidade` (
  `medico_id` int(11) NOT NULL,
  `especialidade_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `tb_medico_especialidade`
--

INSERT INTO `tb_medico_especialidade` (`medico_id`, `especialidade_id`) VALUES
(9, 5),
(10, 5),
(12, 5),
(13, 7),
(14, 4),
(15, 6),
(16, 4),
(17, 9);

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_paciente`
--

CREATE TABLE `tb_paciente` (
  `id` int(11) NOT NULL,
  `us_id` int(11) NOT NULL,
  `nome_completo` varchar(120) NOT NULL,
  `data_nascimento` date NOT NULL,
  `sexo` varchar(50) DEFAULT NULL,
  `telefone` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `tb_paciente`
--

INSERT INTO `tb_paciente` (`id`, `us_id`, `nome_completo`, `data_nascimento`, `sexo`, `telefone`) VALUES
(1, 1, 'FP', '2012-12-12', NULL, '989776509'),
(2, 3, 'FP', '2012-12-12', NULL, '989776509'),
(3, 5, 'FP4', '2012-12-12', NULL, '989776509'),
(4, 7, 'pedro', '2012-12-21', NULL, '989776509'),
(5, 9, 'pedro', '2002-03-31', NULL, '989776509'),
(6, 17, 'pedro', '2012-12-12', NULL, '989776509'),
(7, 19, 'pedro', '2003-12-12', NULL, '989776509'),
(8, 21, 'FP', '2011-02-01', NULL, '989776509'),
(9, 25, 'FP', '2012-12-12', NULL, '989776509'),
(10, 28, 'ana', '2002-12-12', NULL, '989776509'),
(13, 33, 'Ana Hossi', '2012-12-12', NULL, '989776509'),
(14, 34, 'Ana ', '2002-12-12', NULL, '989776509'),
(15, 35, 'Hélvio Coimbra', '2007-02-04', NULL, '921923345'),
(16, 36, 'Milton Gaspar', '2007-05-07', NULL, '924050028'),
(17, 37, 'Teofilo Félix', '1975-02-22', NULL, '940240798');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_perfil`
--

CREATE TABLE `tb_perfil` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_us`
--

CREATE TABLE `tb_us` (
  `id` int(11) NOT NULL,
  `email` varchar(120) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` enum('ativo','inativo') DEFAULT 'ativo',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `tb_us`
--

INSERT INTO `tb_us` (`id`, `email`, `password`, `status`, `created_at`) VALUES
(1, 'fp@gmail.com', '$2y$10$VnqfTxXJz.Zy77DKb2TQbuKUaXFpJx1yKsRUFJBqNhYDYDAq.W6tC', 'ativo', '2026-02-02 09:49:15'),
(3, 'fp4@gmail.com', '$2y$10$1uRO3wHkErlukKcpmVPEKekjMcdZ1UieTMEI73Yc/8xD33WHVr7f.', 'ativo', '2026-02-02 09:51:08'),
(5, 'policarpo4@gmail.com', '$2y$10$SKL.I9GqZmnn5BNio.baze7zRY5gWwYY13EpuK1t7wxUh7WMu4HSe', 'ativo', '2026-02-02 09:54:49'),
(7, 'p@gmail.com', '$2y$10$G8778cwlukycxidN2LK7BOFcVgafTIea6sKY2iZlyxCAbb3E95.aa', 'ativo', '2026-02-02 09:56:22'),
(9, 'pe@gmail.com', '$2y$10$XDl.7Kb37DyIwn4QlQbYauoefJYlv6GYJswvQ94bxOsPZQ0.3CSU6', 'ativo', '2026-02-02 09:58:42'),
(17, 'ped@gmail.com', '$2y$10$3wKm9jd7RSjQqm1t62ZD2uzgEMjFMdfSey0GTk4DjatoKdCM1.fHq', 'ativo', '2026-02-02 10:03:18'),
(19, 'pedr@gmail.com', '$2y$10$bcyGhnPB7rQEneedP3I75uZXw80CL4kkLsOzXxVqfzPK6bobAfDGi', 'ativo', '2026-02-02 10:09:55'),
(21, 'teste@gmail.com', '$2y$10$z/QynYFYYqQRjEuL3cjgbeokG2X92FPjDSqN7.MT/dh53yBq8X0K6', 'ativo', '2026-02-02 10:15:43'),
(25, 'fp5@gmail.com', '$2y$10$2zpVLFXznny5rd775kLhhOAtLHU7TZDDYaTgUmGskaIA2fWcfvsWq', 'ativo', '2026-02-02 10:25:05'),
(28, 'a@gmail.com', '$2y$10$1W0JDeLX9UyG8D2eCiBv1OBtX64OjqyvkObUvUIDBTFUhWZU5spBa', 'ativo', '2026-02-03 07:45:18'),
(33, 'ana@gmail.com', '$2y$10$RT2RLN2O1Tdhr0pi4Z0sV.ldtqSlAYVVOx.EB7HX2bi/WM2eX6/Kq', 'ativo', '2026-02-03 08:19:36'),
(34, 'h@gmail.com', '$2y$10$VBJbFBc6CoAsiwlaN7P2K.TEx.tmvLi74giaqxuP2WW/OJsxERfgi', 'ativo', '2026-02-03 08:22:16'),
(35, 'helvio@gmail.com', '$2y$10$1vJxKQ7q0nZrj4URX2jIve0wgEQRaPaZWig3rbtSeB1tGam56fRZa', 'ativo', '2026-02-03 10:28:43'),
(36, 'miltong@gmail.com', '$2y$10$Cq4ew9aiwrzpPHWQiS8F1.DCu5DutA0emodnxyHfN4de5aFdzQWBK', 'ativo', '2026-02-03 12:26:40'),
(37, 'felixdalaro@gmail.com', '$2y$10$gaTA0mDD9ccFapHi5NPnteGfAFHHLh9wr51sFA4Wb.hwGRTtegoNe', 'ativo', '2026-02-03 12:57:24'),
(52, 'drmario@gmail.com', '$2y$10$xIMBvfes66L7tscdsed7K.uw/lR2Jtz0A0nwDuwKlgmA6O15gnTt6', 'ativo', '2026-02-07 22:18:06'),
(53, 'conceicao@gmail.com', '$2y$10$qZpG.X55LORt8vMwppdV/uTzuMNui1yqJf.Jjs4RD924XM63FyIR2', 'ativo', '2026-02-07 22:20:35'),
(55, 'lopes@gmail.com', '$2y$10$1RYNcEhxUrUXCS.KKEg0P.fCDK4FlA5Vc6CA1UjIgD3Cwf7ACsFGW', 'ativo', '2026-02-08 17:15:06'),
(56, 'palma@gmail.com', '$2y$10$w3UzAacSrjajCmMdgLF2peZcd0N26pgEC7VbwWeNAPbzrdH6JfwHS', 'ativo', '2026-02-08 17:17:22'),
(57, 'asa@gmail.com', '$2y$10$i1F5LVtrjcE2K0DW/SHkcOinNmtkQFJALVyG.L9oVxhx5rWUjrP.q', 'ativo', '2026-02-09 09:14:21'),
(58, 'haniel@gmail.com', '$2y$10$L1EjuoWEUcfLFLq7PioiyuSPc/odyln2JCElYqESwYpRIXxR3y1Dq', 'ativo', '2026-02-26 09:58:25'),
(59, 'priscila@gmail.com', '$2y$10$pM.I./q1PjKe9IUuu3J.Ve6Dkl.R/cskHJONA.g7Xfsv.4Q.1enXa', 'ativo', '2026-02-26 12:22:25'),
(60, 'azancot@gmail.com', '$2y$10$.udxHLT3IbkdQ1j7qTnhJ.jEwYPJg/gcIJYcjaer6rxfJuVySlNHS', 'ativo', '2026-02-26 17:37:50');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_us_perfil`
--

CREATE TABLE `tb_us_perfil` (
  `us_id` int(11) NOT NULL,
  `perfil_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `tb_cargo`
--
ALTER TABLE `tb_cargo`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nome` (`nome`);

--
-- Índices de tabela `tb_consulta`
--
ALTER TABLE `tb_consulta`
  ADD PRIMARY KEY (`id`),
  ADD KEY `horario_id` (`horario_id`),
  ADD KEY `paciente_id` (`paciente_id`);

--
-- Índices de tabela `tb_especialidade`
--
ALTER TABLE `tb_especialidade`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nome` (`nome`);

--
-- Índices de tabela `tb_funcionario`
--
ALTER TABLE `tb_funcionario`
  ADD PRIMARY KEY (`id`),
  ADD KEY `us_id` (`us_id`),
  ADD KEY `cargo_id` (`cargo_id`);

--
-- Índices de tabela `tb_horario`
--
ALTER TABLE `tb_horario`
  ADD PRIMARY KEY (`id`),
  ADD KEY `medico_id` (`medico_id`);

--
-- Índices de tabela `tb_medico`
--
ALTER TABLE `tb_medico`
  ADD PRIMARY KEY (`id`),
  ADD KEY `funcionario_id` (`funcionario_id`);

--
-- Índices de tabela `tb_medico_especialidade`
--
ALTER TABLE `tb_medico_especialidade`
  ADD PRIMARY KEY (`medico_id`,`especialidade_id`),
  ADD KEY `especialidade_id` (`especialidade_id`);

--
-- Índices de tabela `tb_paciente`
--
ALTER TABLE `tb_paciente`
  ADD PRIMARY KEY (`id`),
  ADD KEY `us_id` (`us_id`);

--
-- Índices de tabela `tb_perfil`
--
ALTER TABLE `tb_perfil`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nome` (`nome`);

--
-- Índices de tabela `tb_us`
--
ALTER TABLE `tb_us`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Índices de tabela `tb_us_perfil`
--
ALTER TABLE `tb_us_perfil`
  ADD PRIMARY KEY (`us_id`,`perfil_id`),
  ADD KEY `perfil_id` (`perfil_id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `tb_cargo`
--
ALTER TABLE `tb_cargo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `tb_consulta`
--
ALTER TABLE `tb_consulta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `tb_especialidade`
--
ALTER TABLE `tb_especialidade`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de tabela `tb_funcionario`
--
ALTER TABLE `tb_funcionario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT de tabela `tb_horario`
--
ALTER TABLE `tb_horario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `tb_medico`
--
ALTER TABLE `tb_medico`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT de tabela `tb_paciente`
--
ALTER TABLE `tb_paciente`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT de tabela `tb_perfil`
--
ALTER TABLE `tb_perfil`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `tb_us`
--
ALTER TABLE `tb_us`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `tb_consulta`
--
ALTER TABLE `tb_consulta`
  ADD CONSTRAINT `tb_consulta_ibfk_1` FOREIGN KEY (`horario_id`) REFERENCES `tb_horario` (`id`),
  ADD CONSTRAINT `tb_consulta_ibfk_2` FOREIGN KEY (`paciente_id`) REFERENCES `tb_paciente` (`id`);

--
-- Restrições para tabelas `tb_funcionario`
--
ALTER TABLE `tb_funcionario`
  ADD CONSTRAINT `tb_funcionario_ibfk_1` FOREIGN KEY (`us_id`) REFERENCES `tb_us` (`id`),
  ADD CONSTRAINT `tb_funcionario_ibfk_2` FOREIGN KEY (`cargo_id`) REFERENCES `tb_cargo` (`id`);

--
-- Restrições para tabelas `tb_horario`
--
ALTER TABLE `tb_horario`
  ADD CONSTRAINT `tb_horario_ibfk_1` FOREIGN KEY (`medico_id`) REFERENCES `tb_medico` (`id`);

--
-- Restrições para tabelas `tb_medico`
--
ALTER TABLE `tb_medico`
  ADD CONSTRAINT `tb_medico_ibfk_1` FOREIGN KEY (`funcionario_id`) REFERENCES `tb_funcionario` (`id`);

--
-- Restrições para tabelas `tb_medico_especialidade`
--
ALTER TABLE `tb_medico_especialidade`
  ADD CONSTRAINT `tb_medico_especialidade_ibfk_1` FOREIGN KEY (`medico_id`) REFERENCES `tb_medico` (`id`),
  ADD CONSTRAINT `tb_medico_especialidade_ibfk_2` FOREIGN KEY (`especialidade_id`) REFERENCES `tb_especialidade` (`id`);

--
-- Restrições para tabelas `tb_paciente`
--
ALTER TABLE `tb_paciente`
  ADD CONSTRAINT `tb_paciente_ibfk_1` FOREIGN KEY (`us_id`) REFERENCES `tb_us` (`id`);

--
-- Restrições para tabelas `tb_us_perfil`
--
ALTER TABLE `tb_us_perfil`
  ADD CONSTRAINT `tb_us_perfil_ibfk_1` FOREIGN KEY (`us_id`) REFERENCES `tb_us` (`id`),
  ADD CONSTRAINT `tb_us_perfil_ibfk_2` FOREIGN KEY (`perfil_id`) REFERENCES `tb_perfil` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
